<!-- tp-choose-area-start -->
<div class="tp-choose__area pt-120 pb-90" data-background="{{ asset('assets/frontend/img/choose/choose-bg.png') }}">
   <div class="container">
      <div class="row">
         <div class="col-12">
            <div class="tp-choose__title-box text-center">
               <h3 class="tp-section-title text-white mb-20">{{ get_option('why-choose',true ,true, false, current_locale())->title ?? '' }}</h3>
               <h5 class="tp-choose__subtitle text-white">{{ get_option('why-choose',true, true, false, current_locale())->subtitle ?? '' }}</h5>
            </div>
            <div class="tp-choose__thumb-box d-flex justify-content-center">
            @guest
                       <div class="tp-header__right">
                        <a class="tp-btn d-none d-md-block me-3"
                           href="{{  url('/login') }}"><span>{{ !Auth::check() ? __('Log In') : __('Dashboard') }}</span></a>
                      
                    </div>
                
                    @endguest

                    <div class="tp-header__right">
                        <a class="tp-btn d-none d-md-block ms-3"
                           href="{{ !Auth::check() ? url('/pricing') : url('/login') }}"><span>{{ !Auth::check() ? __('Get Started') : __('Dashboard') }}</span></a>
                      
                    </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- tp-choose-area-end -->

<!-- tp-counter-area-start -->
<div class="tp-counter__area">
   <div class="tp-counter__theme-bg"></div>
   <div class="tp-counter__grey-bg"></div>
   <div class="container">
      <div class="row">
         <div class="col-xl-4 col-lg-4">
            <div class="tp-counter__item d-flex">
               <div class="tp-counter__icon">
                  <img src="{{ asset(get_option('why-choose',true, true, false, current_locale())->left_block_image ?? '') }}" alt="">
               </div>
               <div class="tp-counter__content">
                  <span><i class="counter">{{ get_option('why-choose',true, true, false, current_locale())->left_block_value ?? '' }}</i></span>
                  <p>{{ get_option('why-choose',true, true, false, current_locale())->left_block_title ?? '' }}</p>
               </div>
            </div>
         </div>
         <div class="col-xl-4 col-lg-4">
            <div class="tp-counter__item d-flex">
               <div class="tp-counter__icon">
                  <img src="{{ asset(get_option('why-choose',true, true, false, current_locale())->center_block_image ?? '') }}" alt="">
               </div>
               <div class="tp-counter__content">
                  <span><i class="counter">{{ get_option('why-choose',true, true, false, current_locale())->center_block_value ?? '' }}</i></span>
                  <p>{{ get_option('why-choose',true, true, false, current_locale())->center_block_title ?? '' }}</p>
               </div>
            </div>
         </div>
         <div class="col-xl-4 col-lg-4">
            <div class="tp-counter__item d-flex">
               <div class="tp-counter__icon">
                  <img src="{{ asset(get_option('why-choose',true, true, false, current_locale())->right_block_image ?? '') }}" alt="">
               </div>
               <div class="tp-counter__content">
                  <span><i class="counter">{{ get_option('why-choose',true, true, false, current_locale())->right_block_value ?? '' }}</i></span>
                  <p>{{ get_option('why-choose',true, true, false, current_locale())->right_block_title ?? '' }}</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- tp-counter-area-end -->